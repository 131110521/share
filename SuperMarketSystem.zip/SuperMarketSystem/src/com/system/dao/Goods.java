package com.system.dao;

/**
 * Goods entity. @author MyEclipse Persistence Tools
 */

public class Goods implements java.io.Serializable {

	// Fields

	private Integer gno;
	private String gname;
	private String gup;

	// Constructors

	/** default constructor */
	public Goods() {
	}

	/** minimal constructor */
	public Goods(Integer gno) {
		this.gno = gno;
	}

	/** full constructor */
	public Goods(Integer gno, String gname, String gup) {
		this.gno = gno;
		this.gname = gname;
		this.gup = gup;
	}

	// Property accessors

	public Integer getGno() {
		return this.gno;
	}

	public void setGno(Integer gno) {
		this.gno = gno;
	}

	public String getGname() {
		return this.gname;
	}

	public void setGname(String gname) {
		this.gname = gname;
	}

	public String getGup() {
		return this.gup;
	}

	public void setGup(String gup) {
		this.gup = gup;
	}

}