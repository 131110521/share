package com.system.dao;

/**
 * Userlogin entity. @author MyEclipse Persistence Tools
 */

public class Userlogin implements java.io.Serializable {

	// Fields

	private String username;
	private String password;
	private String sex;
	private String addr;

	// Constructors

	/** default constructor */
	public Userlogin() {
	}

	/** full constructor */
	public Userlogin(String username, String password, String sex, String addr) {
		this.username = username;
		this.password = password;
		this.sex = sex;
		this.addr = addr;
	}

	// Property accessors

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getAddr() {
		return this.addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

}