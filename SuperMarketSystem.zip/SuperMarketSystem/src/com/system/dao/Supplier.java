package com.system.dao;

/**
 * Supplier entity. @author MyEclipse Persistence Tools
 */

public class Supplier implements java.io.Serializable {

	// Fields

	private String sname;
	private String sphone;
	private String scity;

	// Constructors

	/** default constructor */
	public Supplier() {
	}

	/** full constructor */
	public Supplier(String sname, String sphone, String scity) {
		this.sname = sname;
		this.sphone = sphone;
		this.scity = scity;
	}

	// Property accessors

	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSphone() {
		return this.sphone;
	}

	public void setSphone(String sphone) {
		this.sphone = sphone;
	}

	public String getScity() {
		return this.scity;
	}

	public void setScity(String scity) {
		this.scity = scity;
	}

}