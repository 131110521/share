package com.system.service;

import javax.swing.JOptionPane;

public class AddGoods {
	public void addGoods(Integer Gno ,String Gname ,String Gup){
		Management management = new Management();
		try
		{
			if(management.SearchGoods(Gno) != null)
				throw new Exception();

		}
		catch(Exception b)
		{
			JOptionPane.showConfirmDialog(null, "�û����Ѵ���","��ʾ:", JOptionPane.CLOSED_OPTION);
			return;
		}
		management.AddGoods(Gno, Gname, Gup);
		JOptionPane.showConfirmDialog(null, "���ӳɹ�","��ʾ:", JOptionPane.CLOSED_OPTION);	
	}

}
