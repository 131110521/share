package com.system.service;

import javax.swing.JOptionPane;

public class AddSupplier {
	public void addSupplier(String Sname ,String Sphone ,String Scity){
		Management management = new Management();
		try
		{
			if(management.SearchSupplier(Sname) != null)
				throw new Exception();

		}
		catch(Exception b)
		{
			JOptionPane.showConfirmDialog(null, "�ù������Ѵ���","��ʾ:", JOptionPane.CLOSED_OPTION);
			return;
		}
		management.AddSupplier(Sname, Sphone, Scity);
		JOptionPane.showConfirmDialog(null, "���ӳɹ�","��ʾ:", JOptionPane.CLOSED_OPTION);
	}

}
