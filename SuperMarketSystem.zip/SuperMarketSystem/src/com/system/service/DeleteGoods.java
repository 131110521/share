package com.system.service;

import javax.swing.JOptionPane;

public class DeleteGoods {
	public void deleteGoods(Integer Gno){
		Management management = new Management();
		try
		{
			if(management.SearchGoods(Gno) == null)
				throw new Exception();

		}
		catch(Exception b)
		{
			JOptionPane.showConfirmDialog(null, "�û��ﲻ�Ѵ���","��ʾ:", JOptionPane.CLOSED_OPTION);
			return;
		}
		management.DeleteGoods(Gno);
		JOptionPane.showConfirmDialog(null, "ɾ���ɹ�","��ʾ:", JOptionPane.CLOSED_OPTION);
	}
}
