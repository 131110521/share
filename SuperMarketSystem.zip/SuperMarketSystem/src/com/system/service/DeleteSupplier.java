package com.system.service;

import javax.swing.JOptionPane;

public class DeleteSupplier {
	public void deleteSupplier(String Sname){
		Management management = new Management();
		try
		{
			if(management.SearchSupplier(Sname) == null)
				throw new Exception();

		}
		catch(Exception b)
		{
			JOptionPane.showConfirmDialog(null, "�ù�Ӧ�̲��Ѵ���","��ʾ:", JOptionPane.CLOSED_OPTION);
			return;
		}
		management.DeleteSupplier(Sname);
		JOptionPane.showConfirmDialog(null, "ɾ���ɹ�","��ʾ:", JOptionPane.CLOSED_OPTION);
	}
}
