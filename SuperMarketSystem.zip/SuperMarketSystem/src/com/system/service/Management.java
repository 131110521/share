package com.system.service;



import com.system.dao.Goods;
import com.system.dao.GoodsDAO;
import com.system.dao.Supplier;
import com.system.dao.SupplierDAO;
import com.system.dao.Userlogin;
import com.system.dao.UserloginDAO;


public class Management {
	//���ӻ���
		public void AddGoods(Integer Gno ,String Gname ,String Gup){
			Goods a = new Goods(Gno,Gname,Gup);
			GoodsDAO b = new GoodsDAO();
			b.save(a);
		}
	//���ӹ�Ӧ��
	public void AddSupplier(String Sname ,String Sphone ,String Scity){
		Supplier a = new Supplier(Sname, Sphone, Scity);
		SupplierDAO b = new SupplierDAO();
		b.save(a);
	}
	//���ӻ�Ա
	public void AddUser(String username ,String password ,String sex ,String addr){
		Userlogin a = new Userlogin(username ,password ,sex ,addr);
		UserloginDAO b = new UserloginDAO();
		b.save(a);
	}
	//ɾ������
	public void DeleteGoods(Integer Gno){
		GoodsDAO a = new GoodsDAO();
		GoodsDAO b = new GoodsDAO();
		a.delete(b.findById(Gno));	
	}
	//ɾ����Ӧ��
	public void DeleteSupplier(String Sname){
		SupplierDAO a = new SupplierDAO();
		SupplierDAO b = new SupplierDAO();
		a.delete(b.findById(Sname));	
	}
	//���һ���
	public Goods SearchGoods(Integer Gno){
		GoodsDAO a = new GoodsDAO();
		return a.findById(Gno);
	}
	//���ҹ�Ӧ��
	public Supplier SearchSupplier(String Sname){
		SupplierDAO a = new SupplierDAO();
		return a.findById(Sname);
	}
	//����User
	public Userlogin SearchUser(String username){
		UserloginDAO a = new UserloginDAO();
		return a.findById(username);
	}
	//�޸���Ϣ
	public void ModifyUserInformation(String username,String password,String sex,String addr){
			Userlogin user = new Userlogin(username, password, sex, addr);
			UserloginDAO userdao = new UserloginDAO();
			UserloginDAO userdao2 = new UserloginDAO();
			if(userdao.findById(username) != null){
				userdao.delete(userdao2.findById(username));
				userdao.save(user);
			}
	}
	
	

}
