package com.system.service;

import javax.swing.JOptionPane;

public class AddUser {
	public void addUser(String username ,String password ,String sex ,String addr){
	Management management = new Management();
	try
	{
		if(management.SearchSupplier(username) != null)
			throw new Exception();

	}
	catch(Exception b)
	{
		JOptionPane.showConfirmDialog(null, "�ù������Ѵ���","��ʾ:", JOptionPane.CLOSED_OPTION);
		return;
	}
	
	management.AddUser(username, password, sex, addr);
	JOptionPane.showConfirmDialog(null, "���ӳɹ�","��ʾ:", JOptionPane.CLOSED_OPTION);
	}

}
