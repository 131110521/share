package com.system.gui;


import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.system.service.AddGoods;
import com.system.service.Management;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
@SuppressWarnings("serial")
public class AddGoodsGUI extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JLabel jLabel3;
	private JButton jButton1;
	private JButton jButton2;
	private JTextField jTextField3;
	private JTextField jTextField2;
	private JLabel jLabel2;
	private JTextField jTextField1;
	private JLabel jLabel1;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				AddGoodsGUI inst = new AddGoodsGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public AddGoodsGUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.setTitle("\u6dfb\u52a0\u8d27\u7269");
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				jPanel1.setLayout(null);
				LayoutManager jPanel1Layout = null;
				jPanel1.setLayout(jPanel1Layout);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u6dfb\u52a0\u8d27\u53f7\uff1a");
					jLabel1.setBounds(19, 12, 132, 17);
				}
				{
					jTextField1 = new JTextField();
					jPanel1.add(jTextField1);
					jTextField1.setBounds(156, 9, 110, 23);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u6dfb\u52a0\u8d27\u7269\u540d\uff1a");
					jLabel2.setBounds(19, 48, 132, 17);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setBounds(156, 46, 110, 22);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("\u6dfb\u52a0\u8d27\u7269\u5355\u4ef7\uff1a");
					jLabel3.setBounds(19, 87, 132, 17);
				}
				{
					jTextField3 = new JTextField();
					jPanel1.add(jTextField3);
					jTextField3.setBounds(156, 84, 110, 24);
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u786e\u8ba4");
					jButton1.setBounds(298, 45, 68, 24);
					jButton1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							if(jTextField1.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "���Ų���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField1.getText().length()>11)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "���ų��Ȳ��ܳ���11λ","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							
							
							if(jTextField2.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "�������Ʋ���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField2.getText().length()>20)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "��������Ӧ����20��Ӣ���ַ�","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							
							
							if(jTextField3.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "���ﵥ�۲���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField3.getText().length()>255)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "���ﵥ�۲��ܳ���255","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							Integer Gno = Integer.parseInt(jTextField1.getText());
							String Gname = jTextField2.getText();
							String Gup = jTextField3.getText();
							AddGoods addGoods = new AddGoods();
							addGoods.addGoods(Gno, Gname, Gup);
				/*			Management management = new Management();
							try
							{
								if(management.SearchGoods(Gno) != null)
									throw new Exception();

							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "�û����Ѵ���","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							management.AddGoods(Gno, Gname, Gup);
				
							JOptionPane.showConfirmDialog(null, "���ӳɹ�","��ʾ:", JOptionPane.CLOSED_OPTION);	
							dispose();
				*/
						}
					});
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u8fd4\u56de");
					jButton2.setBounds(298, 84, 68, 24);
					jButton2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							dispose();
							//TODO add your code for jButton2.actionPerformed
						}
					});
				}
			}
			pack();
			this.setSize(400, 150);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}

}
