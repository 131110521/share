package com.system.gui;

import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;
import com.system.service.Management;

/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
@SuppressWarnings("serial")
public class SearchSupplierGUI extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel2;
	private JLabel jLabel1;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SearchSupplierGUI inst = new SearchSupplierGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public SearchSupplierGUI() {
		super();
		initGUI();
	}
	
	@SuppressWarnings("static-access")
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.setTitle("\u67e5\u8be2\u7ed3\u679c");
			Management management = new Management();
			SearchGUI searchgui = new SearchGUI();
			management.SearchSupplier(searchgui.keySS);
			management.SearchSupplier(searchgui.keySS).getSphone();
			management.SearchSupplier(searchgui.keySS).getScity();
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				jPanel1.setLayout(null);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u4f9b\u8d27\u5546\u7535\u8bdd\uff1a");
					jLabel1.setBounds(12, 12, 106, 17);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u4f9b\u8d27\u5546\u57ce\u5e02\uff1a");
					jLabel2.setBounds(12, 54, 106, 17);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText(management.SearchSupplier(searchgui.keySS).getSphone());
					jLabel3.setBounds(95, 12, 136, 17);
				}
				{
					jLabel4 = new JLabel();
					jPanel1.add(jLabel4);
					jLabel4.setText(management.SearchSupplier(searchgui.keySS).getScity());
					jLabel4.setBounds(93, 54, 138, 17);
				}
			}
			pack();
			this.setSize(250, 120);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}

}
