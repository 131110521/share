package com.system.gui;

import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.system.service.AddSupplier;
import com.system.service.Management;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
@SuppressWarnings("serial")
public class AddSupplierGUI extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JLabel jLabel3;
	private JButton jButton1;
	private JButton jButton2;
	private JTextField jTextField3;
	private JTextField jTextField2;
	private JTextField jTextField1;
	private JLabel jLabel2;
	private JLabel jLabel1;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				AddSupplierGUI inst = new AddSupplierGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public AddSupplierGUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.setTitle("\u6dfb\u52a0\u4f9b\u8d27\u5546");
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				jPanel1.setLayout(null);
				LayoutManager jPanel1Layout = null;
				jPanel1.setLayout(jPanel1Layout);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u4f9b\u8d27\u5546\u540d\uff1a");
					jLabel1.setBounds(25, 12, 101, 17);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u4f9b\u8d27\u5546\u7535\u8bdd\uff1a");
					jLabel2.setBounds(25, 50, 103, 17);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("\u4f9b\u8d27\u5546\u57ce\u5e02\uff1a");
					jLabel3.setBounds(25, 83, 101, 17);
				}
				{
					jTextField1 = new JTextField();
					jPanel1.add(jTextField1);
					jTextField1.setBounds(126, 5, 101, 24);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setBounds(127, 43, 101, 24);
				}
				{
					jTextField3 = new JTextField();
					jPanel1.add(jTextField3);
					jTextField3.setBounds(126, 79, 101, 26);
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u786e\u8ba4");
					jButton1.setBounds(302, 34, 71, 24);
					jButton1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							if(jTextField1.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "������������Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField1.getText().length()>20)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "������������С��20��Ӣ���ַ�","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							String Sname = jTextField1.getText();
							
							if(jTextField2.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "�����̵绰����Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField2.getText().length()>11)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "�����̵绰Ӧ����11","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							String Sphone = jTextField2.getText();
							
							if(jTextField3.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "�����̳��в���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField3.getText().length()>20)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "�����̳���ӦС��20��Ӣ���ַ�","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							String Scity = jTextField3.getText();
				
							AddSupplier addSupplier = new AddSupplier();
							addSupplier.addSupplier(Sname, Sphone, Scity);
			/*				Management management = new Management();
							try
							{
								if(management.SearchSupplier(Sname) != null)
									throw new Exception();

							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "�ù������Ѵ���","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							
							
							management.AddSupplier(Sname, Sphone, Scity);
						
							JOptionPane.showConfirmDialog(null, "���ӳɹ�","��ʾ:", JOptionPane.CLOSED_OPTION);
							dispose();
							*/	
							//TODO add your code for jButton1.actionPerformed
						}
					});
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u8fd4\u56de");
					jButton2.setBounds(302, 64, 71, 24);
					jButton2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							dispose();
							//TODO add your code for jButton2.actionPerformed
						}
					});
				}
			}
			pack();
			this.setSize(400, 150);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}

}
