package com.system.gui;
import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.SwingUtilities;

import com.system.service.Management;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
@SuppressWarnings({ "unused", "serial" })
public class SearchGUI extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JButton jButton1;
	private JButton jButton3;
	private JTextField jTextField2;
	private JLabel jLabel2;
	private JButton jButton2;
	private JTextField jTextField1;
	private JLabel jLabel1;
	public static Integer keySG;
	public static String keySS;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SearchGUI inst = new SearchGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public SearchGUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.setTitle("\u67e5\u8be2");
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				LayoutManager jPanel1Layout = null;
				jPanel1.setLayout(null);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u8d27\u7269\u7f16\u53f7\uff1a");
					jLabel1.setBounds(12, 12, 122, 17);
				}
				{
					jTextField1 = new JTextField();
					jPanel1.add(jTextField1);
					jTextField1.setBounds(12, 35, 172, 24);
				}
				
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u67e5\u8be2");
					jButton1.setBounds(196, 35, 77, 24);
					jButton1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							if(jTextField1.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "���Ų���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField1.getText().length()>11)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "���ų��Ȳ��ܳ���11λ","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								Management management = new Management();
								management.SearchGoods(Integer.parseInt(jTextField1.getText()));
								keySG = management.SearchGoods(Integer.parseInt(jTextField1.getText())).getGno();
								if(!(management.SearchGoods(Integer.parseInt(jTextField1.getText())).getGno() != null))
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "δ��ѯ���û���","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							
							skip01();
						}
					});
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u53d6\u6d88");
					jButton2.setBounds(196, 127, 77, 24);
					jButton2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							dispose();
			
						}
					});
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u4f9b\u5e94\u5546\u540d\u79f0\uff1a");
					jLabel2.setBounds(12, 65, 166, 17);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setBounds(12, 88, 172, 24);
				}
				{
					jButton3 = new JButton();
					jPanel1.add(jButton3);
					jButton3.setText("\u67e5\u8be2");
					jButton3.setBounds(196, 88, 77, 24);
					jButton3.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							if(jTextField2.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "��Ӧ�����Ʋ���Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField2.getText().length()>20)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "��Ӧ������Ӣ�ĳ��Ȳ��ܳ���20λ","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								String a = jTextField2.getText();
								Management management = new Management();
					//			management.SearchSupplier(jTextField2.getText());
					//			management.SearchSupplier(jTextField2.getText()).getSname();
								keySS = management.SearchSupplier(jTextField2.getText()).getSname();
								if(!(a.equals(management.SearchSupplier(jTextField2.getText()).getSname())))
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "δ��ѯ���ù�����","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							skip02();
							//TODO add your code for jButton3.actionPerformed
						}
					});
				}
			}
			pack();
			this.setSize(300, 200);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	public void skip01(){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SearchGoodsGUI inst = new SearchGoodsGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	public void skip02(){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SearchSupplierGUI inst = new SearchSupplierGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}


}
