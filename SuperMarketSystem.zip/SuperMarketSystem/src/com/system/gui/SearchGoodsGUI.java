package com.system.gui;
import java.awt.BorderLayout;
import java.awt.LayoutManager;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.system.service.Management;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
@SuppressWarnings("serial")
public class SearchGoodsGUI extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel2;
	private JLabel jLabel1;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SearchGoodsGUI inst = new SearchGoodsGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public SearchGoodsGUI() {
		super();
		initGUI();
	}
	
	@SuppressWarnings("static-access")
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.setTitle("\u67e5\u8be2\u8d27\u7269");
			Management management = new Management();
			SearchGUI searchgui = new SearchGUI();
			management.SearchGoods(searchgui.keySG);
			management.SearchGoods(searchgui.keySG).getGname();
			management.SearchGoods(searchgui.keySG).getGup();
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				@SuppressWarnings("unused")
				LayoutManager jPanel1Layout = null;
				jPanel1.setLayout(null);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u8d27\u7269\u540d\u79f0\uff1a");
					jLabel1.setBounds(12, 12, 98, 17);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText(management.SearchGoods(searchgui.keySG).getGname());
					jLabel2.setBounds(116, 17, 63, 16);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("\u8d27\u7269\u5355\u4ef7\uff1a");
					jLabel3.setBounds(12, 53, 98, 17);
				}
				{
					jLabel4 = new JLabel();
					jPanel1.add(jLabel4);
					jLabel4.setText(management.SearchGoods(searchgui.keySG).getGup());
					jLabel4.setBounds(116, 51, 63, 19);
				}
			}
			
			pack();
			this.setSize(250, 120);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}

}
