package com.system.gui;

import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.system.service.Management;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
@SuppressWarnings("serial")
public class ModifyUserInformationGUI extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JPasswordField jPasswordField1;
	private JPasswordField jPasswordField2;
	private JTextField jTextField2;
	private JButton jButton1;
	private JLabel jLabel5;
	private JLabel jLabel6;
	@SuppressWarnings("rawtypes")
	private JComboBox jComboBox1;
	private JButton jButton2;
	private JPasswordField jPasswordField3;
	private JTextField jTextField1;
	private JLabel jLabel2;
	private JLabel jLabel1;
	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				ModifyUserInformationGUI inst = new ModifyUserInformationGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public ModifyUserInformationGUI() {
		super();
		initGUI();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.setTitle("\u4fee\u6539\u4fe1\u606f");
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				@SuppressWarnings("unused")
				LayoutManager jPanel1Layout = null;
				jPanel1.setLayout(null);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u7528\u6237\u540d\uff1a");
					jLabel1.setBounds(12, 6, 91, 17);
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u539f\u5bc6\u7801\uff1a");
					jLabel2.setBounds(12, 34, 92, 17);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("\u65b0\u5bc6\u7801\uff1a");
					jLabel3.setBounds(12, 63, 91, 17);
				}
				{
					jLabel4 = new JLabel();
					jPanel1.add(jLabel4);
					jLabel4.setText("\u786e\u8ba4\u5bc6\u7801\uff1a");
					jLabel4.setBounds(12, 92, 91, 17);
				}
				{
					jTextField1 = new JTextField();
					jPanel1.add(jTextField1);
					jTextField1.setBounds(103, 3, 126, 24);
				}
				{
					jPasswordField1 = new JPasswordField();
					jPanel1.add(jPasswordField1);
					jPasswordField1.setBounds(103, 31, 126, 24);
				}
				{
					jPasswordField2 = new JPasswordField();
					jPanel1.add(jPasswordField2);
					jPasswordField2.setBounds(103, 60, 126, 24);
				}
				{
					jPasswordField3 = new JPasswordField();
					jPanel1.add(jPasswordField3);
					jPasswordField3.setBounds(103, 89, 126, 24);
				}
				{
					jLabel5 = new JLabel();
					jPanel1.add(jLabel5);
					jLabel5.setText("\u6027\u522b\uff1a");
					jLabel5.setBounds(12, 121, 91, 17);
				}
				{
					@SuppressWarnings({ })
					ComboBoxModel jComboBox1Model = 
							new DefaultComboBoxModel(
									new String[] { "Man", "Woman" });
					jComboBox1 = new JComboBox();
					jPanel1.add(jComboBox1);
					jComboBox1.setModel(jComboBox1Model);
					jComboBox1.setBounds(103, 119, 60, 19);
				}
				{
					jLabel6 = new JLabel();
					jPanel1.add(jLabel6);
					jLabel6.setText("\u5730\u5740\uff1a");
					jLabel6.setBounds(12, 150, 91, 17);
				}
				{
					jTextField2 = new JTextField();
					jPanel1.add(jTextField2);
					jTextField2.setBounds(103, 147, 126, 24);
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u786e\u8ba4");
					jButton1.setBounds(103, 177, 79, 24);
					jButton1.addActionListener(new ActionListener() {
						@SuppressWarnings("deprecation")
						public void actionPerformed(ActionEvent evt) {
							if(jTextField1.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "�û�������Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField1.getText().length()>11)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "�û�������С��20��Ӣ���ַ�","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							String username = jTextField1.getText();
							
							if(jPasswordField1.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "ԭ���벻��Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jPasswordField1.getText().length()!=6)
									throw new Exception();
								Long.parseLong(jPasswordField1.getText());
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "����ֻ��Ϊ6λ����","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							
							String sex;
							if(jComboBox1.getSelectedItem().toString().equals("��"))
								sex = "M";
							else
								sex = "F";
							
							if(jPasswordField2.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "�����벻��Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jPasswordField2.getText().length()!=6)
									throw new Exception();
								Long.parseLong(jPasswordField2.getText());
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "����ֻ��Ϊ6λ����","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							String password = jPasswordField2.getText();
							
							if(jPasswordField3.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "ȷ�����벻��Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if((jPasswordField3.getText().length()!=6)||(!(password.equals(jPasswordField3.getText()))))
									throw new Exception();
								Long.parseLong(password);
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "������ȷ�����벻�������������룡","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							if(jTextField2.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "��ַ����Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField2.getText().length()>20)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "��ַ����С��20��Ӣ���ַ�","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							String addr = jTextField2.getText();
		
	
							Management management = new Management();
							String passwordtrue = management.SearchUser(username).getPassword();
							
							try
							{
								if(!passwordtrue.equals((jPasswordField1).getText()))
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "ԭ�����������","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
			
							management.ModifyUserInformation(username, password, sex, addr);
							
							JOptionPane.showConfirmDialog(null, "�޸ĳɹ�","��ʾ:", JOptionPane.CLOSED_OPTION);
							dispose();
			
						}
					});
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u8fd4\u56de");
					jButton2.setBounds(193, 177, 78, 24);
					jButton2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							dispose();
						}
					});
				}
				

			}
			pack();
			this.setSize(300, 250);
			
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}

}
