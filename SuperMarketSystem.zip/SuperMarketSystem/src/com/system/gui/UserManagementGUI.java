package com.system.gui;

import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;

import com.system.service.Management;

/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
@SuppressWarnings("serial")
public class UserManagementGUI extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JLabel jLabel3;
	private JPasswordField jPasswordField1;
	private JButton jButton1;
	private JButton jButton2;
	private JTextField jTextField1;
	private JLabel jLabel2;
	private JLabel jLabel1;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				UserManagementGUI inst = new UserManagementGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public UserManagementGUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.setTitle("\u7528\u6237\u767b\u5f55");
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				@SuppressWarnings("unused")
				LayoutManager jPanel1Layout = null;
				jPanel1.setLayout(null);
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u8d85\u5e02\u8d27\u7269\u7ba1\u7406\u7cfb\u7edf");
					jLabel1.setBounds(123, 18, 202, 17);
					jLabel1.setFont(new java.awt.Font("΢���ź�",0,18));
				}
				{
					jLabel2 = new JLabel();
					jPanel1.add(jLabel2);
					jLabel2.setText("\u7528\u6237\u540d\uff1a");
					jLabel2.setBounds(12, 65, 77, 17);
				}
				{
					jLabel3 = new JLabel();
					jPanel1.add(jLabel3);
					jLabel3.setText("\u5bc6\u7801\uff1a");
					jLabel3.setBounds(12, 101, 36, 17);
				}
				{
					jTextField1 = new JTextField();
					jPanel1.add(jTextField1);
					jTextField1.setBounds(88, 58, 115, 24);
				}
				{
					jPasswordField1 = new JPasswordField();
					jPanel1.add(jPasswordField1);
					jPasswordField1.setBounds(88, 94, 115, 24);
				}
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u767b\u5f55");
					jButton1.setBounds(206, 153, 78, 24);
					jButton1.addActionListener(new ActionListener() {
						@SuppressWarnings("deprecation")
						public void actionPerformed(ActionEvent evt) {
							if(jTextField1.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "�û�������Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jTextField1.getText().length()>11)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "�û�������С��11��Ӣ���ַ�","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							if(jPasswordField1.getText().equals(""))
							{
								JOptionPane.showConfirmDialog(null, "���벻��Ϊ��","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							try
							{
								if(jPasswordField1.getText().length()>6)
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "���볤�Ȳ��ܳ���6λ����","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
							String username = jTextField1.getText();
		
						
							Management management = new Management();
							String password = management.SearchUser(username).getPassword();
							try
							{
								if(!password.equals((jPasswordField1).getText()))
									throw new Exception();
							}
							catch(Exception b)
							{
								JOptionPane.showConfirmDialog(null, "�û����������������","��ʾ:", JOptionPane.CLOSED_OPTION);
								return;
							}
					
							dispose();
							MainGUIskip();
						}
					});
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u6ce8\u518c");
					jButton2.setBounds(295, 153, 78, 24);
					jButton2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							UserRegisterGUIskip();
						}
					});
				}
			}
			pack();
			this.setSize(400, 250);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	protected void UserRegisterGUIskip() {
		
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				AddUserGUI inst = new AddUserGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}

	public void MainGUIskip(){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				MainGUI inst = new MainGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}

}
