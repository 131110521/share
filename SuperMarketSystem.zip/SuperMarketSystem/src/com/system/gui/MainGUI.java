package com.system.gui;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.SwingUtilities;


/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
@SuppressWarnings("serial")
public class MainGUI extends javax.swing.JFrame {
	private JPanel jPanel1;
	private JButton jButton1;
	private JLabel jLabel1;
	private JButton jButton6;
	private JButton jButton5;
	private JButton jButton4;
	private JButton jButton3;
	private JButton jButton2;

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				MainGUI inst = new MainGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public MainGUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			this.setTitle("\u4e3b\u754c\u9762");
			{
				jPanel1 = new JPanel();
				getContentPane().add(jPanel1, BorderLayout.CENTER);
				jPanel1.setLayout(null);
				{
					jButton1 = new JButton();
					jPanel1.add(jButton1);
					jButton1.setText("\u6dfb\u52a0\u8d27\u7269");
					jButton1.setBounds(12, 61, 102, 24);
					jButton1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							skipAG();
							//TODO add your code for jButton1.actionPerformed
						}
					});
				}
				{
					jButton2 = new JButton();
					jPanel1.add(jButton2);
					jButton2.setText("\u6dfb\u52a0\u4f9b\u8d27\u5546");
					jButton2.setBounds(12, 127, 102, 24);
					jButton2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							skipAS();
							//TODO add your code for jButton2.actionPerformed
						}
					});
				}
				{
					jButton3 = new JButton();
					jPanel1.add(jButton3);
					jButton3.setText("\u4fee\u6539\u4fe1\u606f");
					jButton3.setBounds(258, 61, 102, 24);
					jButton3.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							skipMUI();
							//TODO add your code for jButton3.actionPerformed
						}
					});
				}
				{
					jButton4 = new JButton();
					jPanel1.add(jButton4);
					jButton4.setText("\u67e5\u8be2");
					jButton4.setBounds(259, 127, 101, 24);
					jButton4.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							skipS();
							//TODO add your code for jButton4.actionPerformed
						}
					});
				}
				{
					jButton5 = new JButton();
					jPanel1.add(jButton5);
					jButton5.setText("\u5220\u9664\u8d27\u7269");
					jButton5.setBounds(135, 61, 101, 24);
					jButton5.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							skipDG();
							//TODO add your code for jButton5.actionPerformed
						}
					});
				}
				{
					jButton6 = new JButton();
					jPanel1.add(jButton6);
					jButton6.setText("\u5220\u9664\u4f9b\u5e94\u5546");
					jButton6.setBounds(135, 127, 101, 24);
					jButton6.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							skipDS();
							//TODO add your code for jButton6.actionPerformed
						}
					});
				}
				{
					jLabel1 = new JLabel();
					jPanel1.add(jLabel1);
					jLabel1.setText("\u8d85\u5e02\u4fe1\u606f\u7ba1\u7406\u7cfb\u7edf");
					jLabel1.setBounds(12, 12, 360, 27);
					jLabel1.setFont(new java.awt.Font("΢���ź�",0,24));
				}
			}
			pack();
			this.setSize(400, 200);
		} catch (Exception e) {
		    //add your error handling code here
			e.printStackTrace();
		}
	}
	public void skipAG(){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				AddGoodsGUI inst = new AddGoodsGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
		
	}
	public void skipAS(){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				AddSupplierGUI inst = new AddSupplierGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	public void skipDG(){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				DeleteGoodsGUI inst = new DeleteGoodsGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	
	}
	public void skipDS(){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				DeleteSupplierGUI inst = new DeleteSupplierGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	
	}
	public void skipMUI(){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				ModifyUserInformationGUI inst = new ModifyUserInformationGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	
	}
	public void skipS(){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SearchGUI inst = new SearchGUI();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	
	}


}
