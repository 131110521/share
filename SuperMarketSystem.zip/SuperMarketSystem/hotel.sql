/*
Navicat MySQL Data Transfer

Source Server         : UML
Source Server Version : 50515
Source Host           : localhost:3306
Source Database       : hotel

Target Server Type    : MYSQL
Target Server Version : 50515
File Encoding         : 65001

Date: 2015-05-21 19:16:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for booking
-- ----------------------------
DROP TABLE IF EXISTS `booking`;
CREATE TABLE `booking` (
  `reservationID` int(11) NOT NULL,
  `customerName` varchar(20) NOT NULL,
  `customerID` varchar(20) NOT NULL,
  `arriveTime` date NOT NULL,
  `roomNum` int(11) NOT NULL,
  PRIMARY KEY (`reservationID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for checkin
-- ----------------------------
DROP TABLE IF EXISTS `checkin`;
CREATE TABLE `checkin` (
  `roomNum` int(11) NOT NULL,
  `customerID` varchar(6) NOT NULL,
  `checkinTime` date NOT NULL,
  `bookingID` int(6) NOT NULL,
  PRIMARY KEY (`bookingID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for comcustomer
-- ----------------------------
DROP TABLE IF EXISTS `comcustomer`;
CREATE TABLE `comcustomer` (
  `customerID` varchar(6) NOT NULL,
  `personID` varchar(18) NOT NULL,
  `customerName` varchar(20) NOT NULL,
  `sex` varchar(4) NOT NULL,
  PRIMARY KEY (`customerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for consumption
-- ----------------------------
DROP TABLE IF EXISTS `consumption`;
CREATE TABLE `consumption` (
  `bookingID` int(6) NOT NULL,
  `serviceID` int(6) NOT NULL,
  `serviceNum` int(2) NOT NULL,
  PRIMARY KEY (`bookingID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for room
-- ----------------------------
DROP TABLE IF EXISTS `room`;
CREATE TABLE `room` (
  `roomNum` int(11) NOT NULL,
  `roomType` int(1) NOT NULL,
  `state` int(1) NOT NULL,
  PRIMARY KEY (`roomNum`),
  KEY `roomType` (`roomType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for roomtype
-- ----------------------------
DROP TABLE IF EXISTS `roomtype`;
CREATE TABLE `roomtype` (
  `roomType` int(1) NOT NULL,
  `price` double(255,2) NOT NULL,
  `subscription` double(255,2) NOT NULL,
  PRIMARY KEY (`roomType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for service
-- ----------------------------
DROP TABLE IF EXISTS `service`;
CREATE TABLE `service` (
  `serviceID` varchar(11) NOT NULL,
  `serviceName` varchar(20) NOT NULL,
  `servicePrice` double(255,0) NOT NULL,
  PRIMARY KEY (`serviceID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for vipcustomer
-- ----------------------------
DROP TABLE IF EXISTS `vipcustomer`;
CREATE TABLE `vipcustomer` (
  `vipID` int(5) NOT NULL,
  `customerName` varchar(20) NOT NULL,
  `customerID` varchar(20) NOT NULL,
  `sex` varchar(4) NOT NULL,
  `password` varchar(11) NOT NULL,
  PRIMARY KEY (`vipID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
